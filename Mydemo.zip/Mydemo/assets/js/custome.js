var save_method; //for save method string
var table;
var base_url="http://localhost/talkiedo/";


$(document).ready(function() {

    //datepicker
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });
	
    
});

function active_user(id)
{
     bootbox.confirm("Are you sure, you want to activate this producer?", function(result) {
		if(result)
            {
			// ajax delete data to database
			$.ajax({
				url : base_url+"admin/ajax_active/"+id,
				type: "POST",
				dataType: "JSON",
				success: function(data)
				{
					 location.reload();
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error activating producer');
				}
			});

      }
   });
}

function deactive_user(id)
{
     bootbox.confirm("Are you sure, you want to deactivate this producer?", function(result) {
		if(result)
            {
			// ajax delete data to database
			$.ajax({
				url : base_url+"admin/ajax_deactive/"+id,
				type: "POST",
				dataType: "JSON",
				success: function(data)
				{
					 location.reload();
				   
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error deactivating producer');
				}
			});

       }
	 });
}
function updateMovie()
{
     var data = new FormData();
    // append your file
	  data.append('portal_user_id', $('#Producer_name').val());
	  data.append('Movie_by_producer', $('#Movie_by_producer').val());
	  data.append('Movie_name', $('#Movie_name').val());
	  data.append('Release_date', $('#Release_date').val());
	  data.append('Movie_Language', $('#Movie_Language').val());
	  data.append('Language_id', $('#Language_id').val());
	  data.append('poster_image', $('#avatar-edit-img').attr('src'));
	  
    // ajax adding data to database
    $.ajax({
        url : base_url+"Add_Movie/Add_New_Movie",
        type: "POST",
		data: data,
		contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        { 
		     
		             
                if(data.status)
                {
                    alert("success");
					$('#add_movie')[0].reset();
					$("#avatar-edit-img").attr('src', 'default.jpg');
                 }
                else
                 {
                  for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').parent().next().text(data.error_string[i]); //select span help-block class set text error string
                }
                  }


		}
        
    });
}

//Autocomplete Language Search


$(document).ready(function () {
    $("#Movie_Language").on('keypress', function(e) {
        $.ajax({
            type: "POST",
            url: base_url+"Add_Movie/GetAllLanguage",
            data: {
                keyword: $("#Movie_Language").val()
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    $('#DropdownLanguage').empty();
                    $('#Movie_Language').attr("data-toggle", "dropdown");
                    $('#DropdownLanguage').dropdown('toggle');
                }
                else if (data.length == 0) {
                    $('#Movie_Language').attr("data-toggle", "");
                }
                $.each(data, function (key,value) {
                    if (data.length >= 0)
                        $('#DropdownLanguage').append('<li role="presentation" class="form-control"><p class="x_language" id="' + value['language_id'] + '">' + value['language_name'] + '</p></li>');
                });
            }
        });
    });
	
	
    $('ul.txtlanguage').on('click', 'li p', function () {
        $('#Movie_Language').val($(this).text());
		$('.Language_id').val($(this).attr('id'));
		
		
    });
	
	
	
	
	$('#Release_date').datepicker({
         autoclose: true,    // It is false, by default
         format: 'yyyy/mm/dd'
    });
	
});

// select country

function getCountry(id){
	
	$.ajax({
		
		url : base_url+"Common_function/getCountry",
        type: "POST",
        dataType: "JSON",
		data:'continentId='+id,
        success: function(data)
		{
		 $('.countryHide').show();	
         $("#country").empty();
		 $("#country").append("<option value=''> Select Country </option>");
        for (var key in data) {
        if (data.hasOwnProperty(key)) {
         
          		 
          $("#country").append("<option value='" + data[key]["countriesId"]  + "'>" + data[key]["countriesName"] + "</option>");
           
        }
        }
		}
		
		
	});
	
	
}

// get satate

 function getState(id)
 {
	 
	 $.ajax({
		
		url : base_url+"Common_function/getState",
        type: "POST",
        dataType: "JSON",
		data:'countryId='+id,
        success: function(data)
		{
		 $('.steteHide').show();	
         $("#state").empty();
		 $("#state").append("<option value=''> Select States </option>");
        for (var key in data) {
        if (data.hasOwnProperty(key)) {
         
          		 
          $("#state").append("<option value='" + data[key]["statesId"]  + "'>" + data[key]["statesName"] + "</option>");
           
        }
        }
		}
		
		
	});
 }
 
 // get city
 
 function getCity(id)
 {
	 $.ajax({
		
		url : base_url+"Common_function/getCity",
        type: "POST",
        dataType: "JSON",
		data:'statesId='+id,
        success: function(data)
		{
		 $('.cityHide').show();	
         $("#city").empty();
		 $("#city").append("<option value=''> Select City </option>");
        for (var key in data) {
        if (data.hasOwnProperty(key)) {
         
          		 
          $("#city").append("<option value='" + data[key]["citiesId"]  + "'>" + data[key]["citiesName"] + "</option>");
           
        }
        }
		}
		
		
	});
 }
 function addMovie(){
	 var form2 = $('form[id=add_movie]');
      $.ajax({
                url: base_url+"Admin/saveMovie",
                type:'POST',
                data:form2.serialize(),
                success: function(result){
					result = JSON.parse(result);
                    if(result.status)
                    {

					  alert("saved successfully");
					  location.reload();
                    }
                    else
                    {
                      alert("Failed to save"); 
                    }
                }
            }); 
 }
 
 function activateMovie(){
	 
		 var form1 = $('form[id=Activate_movie]');
         var atLeastOneIsChecked = $('.checkbox1:checked').length ;
		 if(atLeastOneIsChecked>0){
			 $.ajax({
                url: base_url+"Admin/activateMovie",
                type:'POST',
                data:form1.serialize(),
                success: function(result){
                   
					result = JSON.parse(result);
                    if(result.status)
                    {

					  alert("updates successfully");
					  location.reload();
                    }
                    else
                    {
                      alert("Failed"); 
                    }
                }
            }); 
        }
		else{
			alert("Please Select Check Box");
		}
	
 }
 
  $('#add_movie1').bootstrapValidator({
                    feedbackIcons: {
                        valid: 'glyphicon glyphicon-ok',
                        invalid: 'glyphicon glyphicon-remove',
                        validating: 'glyphicon glyphicon-refresh'
                    }
                })	.on('success.form.bv', function(e) {
							
            // Prevent form submission
            e.preventDefault();
            $.ajax({
                url: base_url+"Admin/saveMovie",
                type:'POST',
                data:form.serialize(),
                success: function(result){
                    result = JSON.parse(result);
                    if(result.status)
                    {

					  
                    }
                    else
                    {
                      
                    }
                }
            });
            
        });
 
 //upload and previe movie poster
 var loadFile = function(event) {
    oldimg = $('.preview').attr('src');
    var preview = document.getElementById('preview');
    preview.src = URL.createObjectURL(event.target.files[0]);
    newimg = preview.src;
    if(newimg.indexOf('/null') > -1) {
        preview.src = oldimg;
    }
};


		jQuery(document).ready(function(){
		
		/*jQuery('#change-pic').on('click', function(e){
	        jQuery('#changePic').show();
			jQuery('#change-pic').hide();
	        
	    });*/	
		$('#btn-crop').hide();
		jQuery('#Movie_poster').on('change', function()   
		{ 
			jQuery("#preview-avatar-profile").html('');
			jQuery("#preview-avatar-profile").html('Uploading....');
			jQuery("#add_movie").ajaxForm(
			{
			
			url:base_url+'Producer/changeAvatar',
			target: '#preview-avatar-profile',
			success:    function() { 
					jQuery('img#photo').imgAreaSelect({
					aspectRatio: '1:1',
					onSelectEnd: getSizes,
				});
				jQuery('#image_name').val(jQuery('#photo').attr('file-name'));
				
				}
			}).submit();

		});
		
		jQuery('#btn-crop').on('click', function(e){
	    e.preventDefault();
	    params = {
	            targetUrl: base_url+'Producer/saveAvatarTmp',
	            action: 'save',
	            x_axis: jQuery('#hdn-x1-axis').val(),
	            y_axis : jQuery('#hdn-y1-axis').val(),
	            x2_axis: jQuery('#hdn-x2-axis').val(),
	            y2_axis : jQuery('#hdn-y2-axis').val(),
	            thumb_width : jQuery('#hdn-thumb-width').val(),
	            thumb_height:jQuery('#hdn-thumb-height').val()
	        };

	        saveCropImage(params);
	    });
	    
	 
	    
	    function getSizes(img, obj)
	    {   
		    $path=$('#avatar-edit-img').attr('src');
			if($path=="default.jpg"){
				$('#btn-crop').show();
			}
			
	        var x_axis = obj.x1;
	        var x2_axis = obj.x2;
	        var y_axis = obj.y1;
	        var y2_axis = obj.y2;
	        var thumb_width = obj.width;
	        var thumb_height = obj.height;
	        if(thumb_width > 0)
	            {

	                jQuery('#hdn-x1-axis').val(x_axis);
	                jQuery('#hdn-y1-axis').val(y_axis);
	                jQuery('#hdn-x2-axis').val(x2_axis);
	                jQuery('#hdn-y2-axis').val(y2_axis);
	                jQuery('#hdn-thumb-width').val(thumb_width);
	                jQuery('#hdn-thumb-height').val(thumb_height);
					
	                
	            }
	        else
	            alert("Please select portion..!");
	    }
	    
	    function saveCropImage(params) {
			$('#btn-crop').show();
	    jQuery.ajax({
	        url: params['targetUrl'],
	        cache: false,
	        dataType: "html",
	        data: {
	            action: params['action'],
	            id: jQuery('#hdn-profile-id').val(),
	             t: 'ajax',
	                                w1:params['thumb_width'],
	                                x1:params['x_axis'],
	                                h1:params['thumb_height'],
	                                y1:params['y_axis'],
	                                x2:params['x2_axis'],
	                                y2:params['y2_axis'],
									image_name :jQuery('#image_name').val()
	        },
	        type: 'Post',
	       // async:false,
	        success: function (response) {
	                //jQuery('#changePic').hide();
					//jQuery('#change-pic').show();
	                jQuery(".imgareaselect-border1,.imgareaselect-border2,.imgareaselect-border3,.imgareaselect-border4,.imgareaselect-border2,.imgareaselect-outer").css('display', 'none');
	                $('.imgareaselect-selection').remove();
	                jQuery("#avatar-edit-img").attr('src', response);
	                jQuery("#preview-avatar-profile").html('');
	                jQuery("#Movie_poster").val('');
					$('#btn-crop').hide();
	        },
	        error: function (xhr, ajaxOptions, thrownError) {
	            alert('status Code:' + xhr.status + 'Error Message :' + thrownError);
	        }
	    });
	    }
		});
	
 /*Get All Movie by producer*/
 function getMovieByProducer(id){
	
	$.ajax({
		
		url : base_url+"Add_Movie/getMovieByProducer",
        type: "POST",
        dataType: "JSON",
		data:'portal_user_id='+id,
        success: function(data)
		{
			
         $("#Movie_by_producer").empty();
		 $("#Movie_by_producer").append("<option value='0'> Select Movie </option>");
        for (var key in data) {
        if (data.hasOwnProperty(key)) {
         
          		 
          $("#Movie_by_producer").append("<option value='" + data[key]["movie_id"]  + "'>" + data[key]["movie_name"] + "</option>");
           
        }
        }
		}
		
		
	});
	
	
}
/*add movie validation*/
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!

    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    var today = yyyy+'/'+mm+'/'+dd;

    $('.datepickerOne').datepicker({
				autoclose: true,    // It is false, by default
		     	 format: 'yyyy/mm/dd'
			})
        .on('changeDate', function(evt) {
            // Revalidate the date field
            $('#add_movie').bootstrapValidator('revalidateField', $('.datepickerOne').find('[name="From_date[]"]'));
        });
   
    $('#add_movie')
        .bootstrapValidator({
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
				'Producer_name[]': {
                    // The task is placed inside a .col-xs-6 element
                    row: '.col-md-3',
                    validators: {
                        notEmpty: {
                            message: 'The producer name is required'
                        }
                    }
                },
                'Movie_name[]': {
                    // The task is placed inside a .col-xs-6 element
                    row: '.col-md-3',
                    validators: {
                        notEmpty: {
                            message: 'The movie name is required'
                        }
                    }
                },
                'From_date[]': {
                    // The due date is placed inside a .col-xs-4 element
                    row: '.col-md-2',
                    validators: {
                        notEmpty: {
                            message: 'The subscription from date is required'
                        },
						date: {
                            format: 'YYYY/MM/DD',
                            max: 'To_date[]',
							min:today,
                            message: 'The subscription from  date is not a valid'
                        }
                    }
                },
				'To_date[]': {
                    // The due date is placed inside a .col-xs-4 element
                    row: '.col-md-2',
                    validators: {
                        notEmpty: {
                            message: 'The subscription to date is required'
                        },
						date: {
                            format: 'YYYY/MM/DD',
                            min: 'From_date[]',
                            message: 'The subscription to date is not a valid'
                        }
                    }
                }
            }
        })

        .on('added.field.fv', function(e, data) {
			    if (data.field === 'From_date[]') {
                // The new due date field is just added
                // Create a new date picker
				
			      data.element
                    .parent()
                    .datepicker({
                        format: 'yyyy/mm/dd'
                    })
                    .on('changeDate', function(evt) {
                        // Revalidate the date field
                        $('#add_movie').bootstrapValidator('revalidateField', data.element);
                    });
            }
			if (data.field === 'To_date[]') {
                // The new due date field is just added
                // Create a new date picker
                data.element
                    .parent()
                    .datepicker({
                        format: 'yyyy/mm/dd'
                    })
                    .on('changeDate', function(evt) {
                        // Revalidate the date field
                        $('#add_movie').bootstrapValidator('revalidateField', data.element);
                    });
            }
        })

        // Add button click handler
        .on('click', '.addButton', function() {
			//var $num=$('input[name*="Movie_name[]"]').length;
			var $num=$('.number').length;
			var $template = $('#taskTemplate'),
                $clone    = $template
                                .clone()
                                .removeClass('hide')
								.attr('data-row', $num)
                                .removeAttr('id')
                                .insertBefore($template);
			 $('.datepickerOne').datepicker({
				autoclose: true,    // It is false, by default
		     	 format: 'yyyy/mm/dd'
			})
			.on('changeDate', function(evt) {
				// Revalidate the date field
				$('#add_movie').bootstrapValidator('revalidateField', $('.datepickerOne').find('[name="From_date[]"]'));
			});
			 $('.datepickerOne').datepicker({
				autoclose: true,    // It is false, by default
		     	 format: 'yyyy/mm/dd'
			})
			.on('changeDate', function(evt) {
				// Revalidate the date field
				$('#add_movie').bootstrapValidator('revalidateField', $('.datepickerOne').find('[name="To_date[]"]'));
			});

            // Add new fields
            // Note that we DO NOT need to pass the set of validators
            // because the new field has the same name with the original one
            // which its validators are already set
            $('#add_movie')
			    .bootstrapValidator('addField', $clone.find('[name="Producer_name[]"]'))
                .bootstrapValidator('addField', $clone.find('[name="Movie_name[]"]'))
                .bootstrapValidator('addField', $clone.find('[name="From_date[]"]'))
				.bootstrapValidator('addField', $clone.find('[name="To_date[]"]'))
        })

        // Remove button click handler
        .on('click', '.removeButton', function() {
            var $row = $(this).closest('.form-group');

            // Remove fields
            $('#add_movie')
                .bootstrapValidator('removeField', $row.find('[name="task[]"]'))
                .bootstrapValidator('removeField', $row.find('[name="Movie_name[]"]'))
                .bootstrapValidator('removeField', $row.find('[name="From_date[]"]'))
				.bootstrapValidator('removeField', $row.find('[name="To_date[]"]'))
            // Remove element containing the fields
            $row.remove();
        }).on('success.form.bv', function(e) {
							
            // Prevent form submission
            e.preventDefault();
			var form2 = $('form[id=add_movie]');
            $.ajax({
                url: base_url+"admin/movieExist",
                type:'POST',
                data:form2.serialize(),
                success: function(result){
                    result = JSON.parse(result);
                    if(result.status)
                    {
						  $.ajax({
									url: base_url+"Admin/saveMovie",
									type:'POST',
									data:form2.serialize(),
									success: function(data){
													  
							       result = JSON.parse(data);
							       if(result.status) //if success give alert and clear all field
									{
										alert(' add  data success');
										$("#add_movie")[0].reset();
										
										
									}
									
									$('#btnSaveP').text('save'); //change button text
									//$('#btnSaveP').attr('disabled',false); //set button enable 
							}
					});
					   

                    }
                    else
                    {
                        var ids= result.ids;
						for(var i=0; i<ids.length; i++){
							var j=ids[i];
							$('.form-group[data-row='+j+'] .movieName').val('');
							//$('#tableAddMovie tr:gt('+j+')  .movieName').val('');
						}
                        bootbox.alert("Movie Name already exists.");
                      //  $('#add_movie').bootstrapValidator('revalidateField', 'Movie_Name[]');
                    }
                }
            });
            
        });


//Admin Add Movie Form validation And form Submit Function 
    
    /*$('#add_movie').bootstrapValidator({
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                'Movie_name[]': {
                    err: '#messageContainer',
                    validators: {
                        notEmpty: {
                            message: 'The movie name is required and can not be empty'
                        },
                        callback: {
                            callback: function(value, validator, $field) {
                                var $movies          = validator.getFieldElements('Movie_name[]'),
                                    numMovies        = $movies.length,
                                    notEmptyCount    = 0,
                                    obj              = {},
                                    duplicateRemoved = [];

                                for (var i = 0; i < numMovies; i++) {
                                    var v = $movies.eq(i).val();
                                    if (v !== '') {
                                        obj[v] = 0;
                                        notEmptyCount++;
                                    }
                                }

                                for (i in obj) {
                                    duplicateRemoved.push(obj[i]);
                                }

                                if (duplicateRemoved.length === 0) {
                                    return {
                                        valid: false,
                                        message: 'You must fill at least one movie name'
                                    };
                                } else if (duplicateRemoved.length !== notEmptyCount) {
                                    return {
                                        valid: false,
                                        message: 'The movie name must be unique'
                                    };
                                }

                                validator.updateStatus('Movie_name[]', validator.STATUS_VALID, 'callback');
                                return true;
                            }
                        }
                    }
                }
            }
        }) .on('success.form.bv', function(e) {
							
            // Prevent form submission
            e.preventDefault();
			var form2 = $('form[id=add_movie]');
            $.ajax({
                url: base_url+"admin/movieExist",
                type:'POST',
                data:form2.serialize(),
                success: function(result){
                    result = JSON.parse(result);
                    if(result.status)
                    {
						  $.ajax({
									url: base_url+"Admin/saveMovie",
									type:'POST',
									data:form2.serialize(),
									success: function(data){
													  
							       result = JSON.parse(data);
							       if(result.status) //if success give alert and clear all field
									{
										alert(' add  data success');
										$("#add_movie")[0].reset();
										
										
									}
									
									$('#btnSaveP').text('save'); //change button text
									//$('#btnSaveP').attr('disabled',false); //set button enable 
							}
					});
					   

                    }
                    else
                    {
                        var ids= result.ids;
						for(var i=0; i<ids.length; i++){
							var j=ids[i];
							
							$('#tableAddMovie tr:gt('+j+')  .movieName').val('');
						}
                        bootbox.alert("Movie Name already exists.");
                      //  $('#add_movie').bootstrapValidator('revalidateField', 'Movie_Name[]');
                    }
                }
            });
            
        });
 */
//Registe New Producer
 /*function register_producer()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    
       var url = base_url+"producer/add_producer";
       var data = new FormData();
    // append your file
	  data.append('producer_name', $('#producer_name').val());
      data.append('company_logo', $('input[type=file]')[0].files[0]);
	  data.append('continent', $('#continent').val());
	  data.append('country', $('#country').val());
	  data.append('state', $('#state').val());
	  data.append('city', $('#city').val());
	  data.append('address1', $('#address1').val());
	  data.append('address2', $('#address2').val());
	  data.append('address3', $('#address3').val());
	  data.append('pin_id', $('#pin_id').val());
	  data.append('contact_email', $('#contact_email').val());
	  data.append('password', $('#password').val());
	   data.append('confirm_password', $('#confirm_password').val());
	  data.append('personal_email', $('#personal_email').val());
	  data.append('contact_no1', $('#contact_no1').val());
	  data.append('contact_no2', $('#contact_no2').val());
	  data.append('about_company', $('#about_company').val());
	  
       
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: data,
		contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        { 
		  
           
            if(data.status) //if success give alert and clear all field
            {
                alert(' add  data success');
				$("#add_producer")[0].reset();
				
				
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        
    });
}
*/






            






